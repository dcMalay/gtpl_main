import 'package:flutter/cupertino.dart';

class LoginProvider extends ChangeNotifier {
  String? selectedValue;

  void onChanged(String? value) {
    selectedValue = value;
    notifyListeners();
  }
}
