import 'package:gtpl/query/global_handler.dart';
import 'package:gtpl/view/home.dart';
import 'package:gtpl/view/login/login.dart';

class CallBackSplash {
  Future<void> onDoneLoading(context) async {
    var userid = await GlobalHandler.getCustomerNo();
    if (userid != null) {
      GlobalHandler.navigatorPushReplacement(context, const Home());
    } else {
      GlobalHandler.navigatorPushReplacement(context, const LoginScreen());
    }
    // Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
    //   return const HomePage();
    // }));
  }
}
