import 'package:flutter/material.dart';

const base_url = 'http://3.111.229.113:3000';

Color primaryColor = Colors.blueGrey.shade900;
Color greenColor = Colors.green;
