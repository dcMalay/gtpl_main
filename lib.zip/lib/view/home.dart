import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:gtpl/query/get_cable_detail.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  GetUserDetailsModel? dsValue;

  @override
  void initState() {
    getUserDetails(context).then((value) {
      setState(() {
        dsValue = value;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return dsValue == null
        ? const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          )
        : Scaffold(
            body: ListView(
              padding: const EdgeInsets.all(0),
              children: [
                Stack(
                  children: [
                    Image.asset(
                      'assets/Rectangle 181.png',
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 40,
                          ),
                          const Text(
                            "My Account",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 22),
                          ),
                          ListTile(
                            leading: const Icon(
                              Icons.person,
                              color: Colors.white,
                            ),
                            title: Text(
                              '${dsValue!.cableResult!.fIRSTNAME.toString()} ${dsValue!.cableResult!.mIDDLENAME.toString()} ${dsValue!.cableResult!.lASTNAME!.toString()}',
                              style: const TextStyle(color: Colors.white),
                            ),
                            subtitle: Text(
                              dsValue!.cableResult!.cONTACTINFO!.mOBILEPHONE
                                  .toString(),
                              style: TextStyle(color: Colors.white),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                )
              ],
            ),
          );
  }
}
