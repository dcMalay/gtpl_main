import 'package:flutter/material.dart';
import 'package:gtpl/const/const.dart';
import 'package:gtpl/provider/login.dart';
import 'package:gtpl/query/global_handler.dart';
import 'package:gtpl/view/home.dart';
import 'package:gtpl/view/login/components/dropdown.dart';
import 'package:pinput/pinput.dart';
import 'package:provider/provider.dart';

class VerifyScreen extends StatefulWidget {
  final String customerNo;
  final String phone;
  final int otp;
  const VerifyScreen(
      {Key? key,
      required this.phone,
      required this.otp,
      required this.customerNo})
      : super(key: key);

  @override
  State<VerifyScreen> createState() => _VerifyScreenState();
}

class _VerifyScreenState extends State<VerifyScreen> {
  final defaultPinTheme = PinTheme(
    width: 56,
    height: 56,
    textStyle: TextStyle(
        fontSize: 20,
        color: Color.fromRGBO(30, 60, 87, 1),
        fontWeight: FontWeight.w600),
    decoration: BoxDecoration(
      border: Border.all(color: Color.fromRGBO(234, 239, 243, 1)),
      borderRadius: BorderRadius.circular(20),
    ),
  );
  PinTheme? focusedPinTheme;
  PinTheme? submittedPinTheme;
  @override
  void initState() {
    focusedPinTheme = defaultPinTheme.copyDecorationWith(
      border: Border.all(color: Color.fromRGBO(114, 178, 238, 1)),
      borderRadius: BorderRadius.circular(8),
    );

    submittedPinTheme = defaultPinTheme.copyWith(
      decoration: defaultPinTheme.decoration!.copyWith(
        color: Color.fromRGBO(234, 239, 243, 1),
      ),
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          Center(
            child: Text(
              'Skip',
              style: TextStyle(color: Theme.of(context).primaryColor),
            ),
          ),
          const SizedBox(
            width: 15,
          )
        ],
        leading: BackButton(
          color: Theme.of(context).primaryColor,
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        children: [
          Text(
            'Verify Your Account',
            style: TextStyle(
                color: Theme.of(context).primaryColor,
                fontSize: 25,
                fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Text(
            'Enter the OTP sent to your registered mobile number',
            style: TextStyle(
              color: greycolor,
              fontSize: 12,
            ),
          ),
          Text(
            'Your number +91 ${widget.phone.replaceFirst(RegExp(r'\d{5}'), '*****')}',
            style: TextStyle(
              color: greycolor,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 20),
          Pinput(
            length: 6,
            defaultPinTheme: defaultPinTheme,
            focusedPinTheme: focusedPinTheme,
            submittedPinTheme: submittedPinTheme,
            validator: (s) {
              if (s == widget.otp.toString()) {
                GlobalHandler.setCustomerNo(widget.customerNo);
                GlobalHandler.navigatorPushReplacement(context, Home());
                return null;
              } else {
                return 'Pin is incorrect';
              }
            },
            pinputAutovalidateMode: PinputAutovalidateMode.onSubmit,
            showCursor: true,
            onCompleted: (pin) => print(pin),
          )
        ],
      ),
      bottomNavigationBar: Container(
        height: 70,
        padding: const EdgeInsets.all(10),
        decoration: const BoxDecoration(boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 3, spreadRadius: 2),
        ], color: Colors.white),
        child: InkWell(
          onTap: () {},
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Theme.of(context).primaryColor,
            ),
            child: const Center(
              child: Text("Verify now",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        ),
      ),
    );
  }
}
